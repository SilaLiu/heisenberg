#ifndef __ROLLER_EYE_BLOCK_QUEUE_H__
#define __ROLLER_EYE_BLOCK_QUEUE_H__
#include<mutex>
#include<queue>
#include <condition_variable>
#include"plterrno.h"

/*
消息队列模板，
支持阻塞，非阻塞操作
*/
using namespace std;
namespace pixbot{
 template<class T>
class BlockQueue{
public:
    /*
    max: 最大容纳的元素个数
    */
    BlockQueue(int max):mMax(max)
    {

    }
    ~BlockQueue()
    {

    }
   /*
   非阻塞的方式向消息队列添加消息
   */
    int pushNoblock(T& t)
    {
        unique_lock<mutex> lock(mMutex);
        if(mMax>0&&(int)mQueue.size()>=mMax){
            pset_errno(PEFULL);
            return -1;
        }
        mQueue.push(t);
        if(mQueue.size()==1){
            mCondR.notify_all();
        }
        return 0;
    }
   /*
   阻塞的方式向消息队列添加消息
   */
     void push(T& t)
    {
        unique_lock<mutex> lock(mMutex);
        while(mMax>0&&(int)mQueue.size()>=mMax){
            mCondW.wait(lock);
        }
        mQueue.push(t);
        if(mQueue.size()==1){
            mCondR.notify_all();
        }
    }
   /*
   阻塞的方式从消息队列读取元素
   */
    void pop(T& t)
    {
        unique_lock<mutex> lock(mMutex);
        while(mQueue.size()==0)
        {
            mCondR.wait(lock);
        }
     
        t = mQueue.front(); 
        mQueue.pop();

        if(mMax>0 && (int)mQueue.size()==mMax-1)
        {
            mCondW.notify_all();
        }
    }
    /*
   非阻塞的方式从消息队列读取元素
   */   
    int popNoblock(T& t)
    {
        unique_lock<mutex> lock(mMutex);
        if(mQueue.size()==0)
        {
            pset_errno(PEEMPTY);
            return -1;
        }
     
        t = mQueue.front(); 
        mQueue.pop();

        if(mMax>0 && (int)mQueue.size()==mMax-1)
        {
            mCondW.notify_all();
        }
        return 0;
    }
   /*
   清空消息队列
   */
    void clear(){
        unique_lock<mutex> lock(mMutex);
        while(!mQueue.empty()){
            mQueue.pop();
        }
        mCondW.notify_all();
    }
    /*
    判断消息队列是否为空
    */
    bool empty(){
        unique_lock<mutex> lock(mMutex);
        return mQueue.empty();
    }
private:
    int mMax;
    mutex mMutex;
    condition_variable mCondW;
    condition_variable mCondR;
    queue<T> mQueue;
};
}
#endif