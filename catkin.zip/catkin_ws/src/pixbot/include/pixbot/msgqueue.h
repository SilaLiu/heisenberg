#ifndef __MSG_QUEUE__H___
#define __MSG_QUEUE__H___
#ifdef __cplusplus
extern "C"{
#endif

struct pqueue_msg{
    int msg;
    int pars;
    void* parc;
};

typedef void* QHandle;
typedef void (*queue_proc)(struct pqueue_msg *msg );

/*
创建消息队列
max：消息队列最大的元数个数
queue_proc：执行pqueue_pop时的回调
*/
QHandle pqueue_create(int max,queue_proc proc);
int pqueue_destroy(QHandle handle);
/*
将一个消息放入消息队列
wait:如果wait=1,消息队列满了之后会一直等待，wait=0,消息队列满了，返回出错
*/
int pqueue_push(QHandle handle,struct pqueue_msg msg,int wait);
/*
非阻塞方式处理消息队列的一个消息，如果队列为空，返回出错
*/
int pqueue_pop(QHandle handle);//noblock
/*
阻塞方式处理消息队列的一个消息，如果队列为空，等待
timeout：<=0永远等待，>0表示需要等待的微妙数
*/
int pqueue_pop_timeout(QHandle handle,int timeout);//block
/*
返回一个fd，如果消息队列不为空，则fd可读，每读出一个消息，需read该fd的一个字节
*/
int pqueue_get_notify_fd(QHandle handle);

#ifdef __cplusplus
}
#endif
#endif