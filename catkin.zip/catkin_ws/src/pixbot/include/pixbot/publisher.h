/*
ros publisher封装
加入了侦听客户端订阅和退出订阅的回调
*/
#ifndef __ROLLER_EYE_PUBLISHER__H__
#define __ROLLER_EYE_PUBLISHER__H__
#include<atomic>
#include"plt_assert.h"
#include<functional>
#include"ros/ros.h"

using namespace std;
namespace pixbot{

typedef std::function<void(int)> ClientIn;
typedef std::function<void(int)> ClientOut;

template<class T>
 class Publisher{
public:
    /*
    in:客户端发起订阅时，执行一次回调
    out：客户端退出订阅时，执行一次回调
    */
    Publisher(ros::NodeHandle &n,string name,int buff,const ClientIn& in,const ClientOut& out):
    mConnec(0),
    mIn(in),
    mOut(out)
    {
        init(n,name,buff);
    }
    Publisher(ros::NodeHandle &n,string name,int buff,const ClientIn& in):
    mConnec(0),
    mIn(in),
    mOut(nullptr)
    {
        init(n,name,buff);
    }
    Publisher(ros::NodeHandle &n,string name,int buff):
    mIn(nullptr),
    mOut(nullptr)
    {
        init(n,name,buff);
    }
    ~Publisher()
    {

    }
    void subcriberConnect(const ros::SingleSubscriberPublisher& sub)
    {
        int cnt=++mConnec;
        if(mIn){
            plt_assert(cnt>0);
            mIn(cnt);
        }
    }
    void disconnectConnect(const ros::SingleSubscriberPublisher& sub)
    {
        int cnt=--mConnec;
        if(mOut){
            plt_assert(cnt>=0);
            mOut(cnt);
        }
    }

    void publish(const T& msg){
        mPub.publish(msg);
    }

protected:
     void init(ros::NodeHandle &n,string name,int buff)
     {
         const ros::SubscriberStatusCallback conCB=bind(&Publisher::subcriberConnect,this,placeholders::_1);
        const ros::SubscriberStatusCallback disCB=bind(&Publisher::disconnectConnect,this,placeholders::_1);
         mPub=n.advertise<T>(name,buff,conCB,disCB);
     }
    ros::Publisher mPub;
    atomic<int> mConnec;
    ClientIn mIn;
    ClientOut mOut;
};
}
#endif