#ifndef __ROLLER_EYE_VERSION_H__
#define __ROLLER_EYE_VERSION_H__

#define HW_VERSION "HW_10_00"
#define SW_VERSION "00_00_00_020311"
#define SW_BUILD_TIME "2022-03-08 02:01:23"
#define SW_GIT_VERSION "32f38ce"

#endif