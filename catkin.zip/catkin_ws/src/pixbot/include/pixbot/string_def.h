#ifndef __ROLLER_EYE_STRING_DEFINE_H__
#define __ROLLER_EYE_STRING_DEFINE_H__

#define JSON_FIELD_ID                   "id"
#define JSON_FIELD_CMD              "cmd"
#define JSON_FIELD_RESP             "response"
#define JSON_FIELD_TOKEN          "token"
#define JSON_FIELD_BODY             "body"
#define JSON_FIELD_SN                   "sn"
#define JSON_FIELD_TYPE             "type"
#define JSON_FIELD_STATUS           "status"

//app cmd
#define CMD_QUERY_INFO              "sn"
#define CMD_SET_WIFI                    "wifi"
#define CMD_SWITCH_WIFI           "wifi_switch"
#define CMD_BIND_USER               "bind"
#define CMD_WIFI_MOD                    "wifi_mod"
#define CMD_DOWNLOAD_BEGIN   "download_begin"
#define CMD_DOWNLOAD_END   "download_end"
#define CMD_DOWNLOAD_RETRY   "download_retry"
#define CMD_QUERY_P2P                   "p2p"
#define CMD_RECORD_START            "record_start"
#define CMD_RECORD_STOP            "record_stop"
#define CMD_RECORD_FILE_NUM            "record_get_file_num"
#define CMD_RECORD_FILE_LIST            "record_get_file_list"
#define CMD_RECORD_FILE_DELETE            "record_delete_file"
#define CMD_RECORD_STATUS               "record_status"
#define CMD_SET_RESOLUTION              "set_resolution"
#define CMD_GET_RESOLUTION              "get_resolution"
#define CMD_SYSTEM_STATUS               "status"
#define CMD_IBEACON_STATUS              "ibeacon"
#define CMD_SCRATCH_SEND                   "send_scrath_script"
#define CMD_NAV_QUERY_POSE                             "nav_query_pose"
#define CMD_NAV_START                               "nav_start"
#define CMD_NAV_SAVE                                    "nav_save"
#define CMD_NAV_DELETE                              "nav_delete"
#define CMD_NAV_LIST                                      "nav_list"
#define CMD_NAV_PATROL                                 "nav_patrol"
#define CMD_NAV_BACK                                 "nav_back"
#define CMD_NAV_CANCEL                            "nav_cancel"
#define CMD_NAV_OUT                                    "nav_out"
#define CMD_SCHED_ADD                               "timer_task_add"
#define CMD_SCHED_EDIT                              "timer_task_edit"
#define CMD_SCHED_DELETE                        "timer_task_delete"
#define CMD_SCHED_LIST                                 "timer_task_list"
#define CMD_GET_WIFI_LIST                           "get_wifi_list"
#define CMD_SET_PARAM                           "set_param"
#define CMD_GET_PARAM                           "get_param"

#define CMD_GET_OTA_STATUS                    "getOtaStatus"
#define CMD_QUERY_OTA_VER                       "queryOtaVer"
#define CMD_START_OTA_UPGRADE                   "startOtaUpgrade"
#define CMD_START_OTA_DOWNLOAD                  "startOtaDownload"
#define CMD_START_OTA_INSTALL                   "startOtaInstall"
#define CMD_GET_CURRENT_VER                     "getCurrentVer"

#define CMD_STOP_PROGRAMMING                    "stopProgramming"
#define CMD_PROGRAMMING_EXCEPTION               "programmingException"
#define CMD_PROGRAMMING_META                    "programmingMeta"
#define CMD_PROGRAMMING_MSG                     "programmingMsg"

#define CMD_CLEAN                               "reset"

//ces cmd
#define CMD_DEMO_CES                               "demo_ces"

//for cloud cmd
#define CMD_LOGIN                          "login"
#define CMD_AUTH                                 "auth"
#define CMD_PUSH_TOKENS              "pushBindToken"
#define CMD_REPORT_P2P_KEYS        "reportP2Pkeys"
#define CMD_SAVE_FILE                                "saveFile"
#define CMD_START_STREAM                       "startStream"
#define CMD_QUERY_STREAM                "queryStream"
#define CMD_HEART_BEART                "heartBeat"
#define CMD_TIMER_TASK_NOTICE       "timerTaskReport"
#define CMD_OTA_QUERY               "otaQuery"
#define CMD_OTA_START_IN_WL         "otaStartInWl"

#define JSON_TYPE_REQ               "request"
#define JSON_TYPE_ANS               "answer"
#define JSON_TYPE_RPT               "report"
#define JSON_TYPE_PUSH              "push"
#define JSON_TYPE_CMD               "cmd"
#define JSON_TYPE_RES               "response"

//for p2p cmd
#define  CMD_ID_QUERY_OTA_VER        "3006"
#define  CMD_ID_START_OTA_DOWNLOAD   "3007"
#define  CMD_ID_START_OTA_INSTALL    "3008"
#define  CMD_ID_GET_OTA_STATUS       "3011"

#define  CMD_ID_PROGRAMMING_RUN      "4001"



#endif