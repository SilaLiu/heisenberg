#ifndef ROLLER_EYE_UTIL_CLASS_H
#define ROLLER_EYE_UTIL_CLASS_H
#include<string>
#include<vector>
#include <sys/statfs.h>

using namespace std;
namespace pixbot
{
    //计算时间消耗，起始时执行reset，结束时执行cost()获取消耗时间，单位为毫秒
    class TimeCost{
        public:
            TimeCost();
            void reset();
            int cost();
        private:
            uint64_t mCurrent;
    };
    bool readVector3fCalibration(const string &file,double calib[3]);
    void saveVector3fCalibration(const string &file,double calib[3]);
    /*
    从指定文件读取double序列
    */
    bool readCalibration(const string &file,double *calib,int cnt);
    /*
    将double序列保存到指定文件
    */
    void saveCalibration(const string &file,double *calib,int cnt);
    /*
    列出指定目录的所有文件
    path：目录路径
    files：返回的文件名
    excludeDir：true表示排除文件夹
    */
    bool listDir(const string& path,vector<string>& files,bool excludeDir=true);

    bool detectProcessIsExited(string processName);

    void stopProgramming();

    bool getFreeSpace(string dirName, unsigned long long *free);

    string runCmdAndGetResult(string cmdStr);
} // namespace pixbot

#endif