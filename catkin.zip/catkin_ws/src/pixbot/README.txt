pixbot

编译方法:
mkdir ProjDir
cd ProjDir
mkdir src
cd src
git clone 项目git地址
cd ..
catkin_make

开发环境推荐：Ubuntu 18.04、 ROS Melodic

开发IDE推荐用: Visual Code Code








