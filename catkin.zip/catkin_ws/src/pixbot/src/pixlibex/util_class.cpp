#include "pixbot/util_class.h"
#include"plt_tools.h"
#include"plog_plus.h"
#include<libgen.h>
#include <sys/stat.h>
#include <sys/types.h>
#include<cstdio>
#include<fstream>
#include <dirent.h>

namespace pixbot
{
    static const std::string UTIL_CLASS_TAG="utils";

    TimeCost::TimeCost()
    {
        reset();
    }
    void TimeCost::reset()
    {
        mCurrent=plt_get_mono_time_ms();
    }
    int TimeCost::cost()
    {
        return (int)(plt_get_mono_time_ms()-mCurrent);
    }
};
