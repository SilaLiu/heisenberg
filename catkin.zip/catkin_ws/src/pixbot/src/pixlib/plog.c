#include<stdio.h>
#include<sys/time.h>
#include<string.h>
#include <syslog.h>
#include<stdarg.h>
#include "plog.h"
#include"plterrno.h"

static int g_level=PLOG_LEVEL_INFO;
static int g_inited=0;

void plog_init(int level)
{
    if(!g_inited){
        g_inited=1;
       plog_setlevel(level);
        openlog(NULL,LOG_PID|LOG_CONS,LOG_USER);
    }else{
        //fprintf(stderr,"log module has been inited\n");
    }
    
}
void plog_setlevel(int level)
{
    if(level>=PLOG_LEVEL_DEBUG&&level<PLOG_LEVEL_MAX){
        g_level=level;
    }else{
        fprintf(stderr,"LOG Level is out of range\n");
    }
}
static int mapLevel(int level)
{
        int syslevel;
        switch (level)
        {
        case PLOG_LEVEL_DEBUG:
            syslevel=LOG_DEBUG;
            break;
        case PLOG_LEVEL_INFO:
            syslevel=LOG_INFO;
            break;
        case PLOG_LEVEL_WARNING:
            syslevel=LOG_WARNING;
            break;
        case PLOG_LEVEL_ERROR:
            syslevel=LOG_ERR;
            break;
        case PLOG_LEVEL_FATAL:
            syslevel=LOG_CRIT;
            break;
        default:
            syslevel=LOG_NOTICE;
            break;
        }
        return syslevel;
}
int __plog_write(const char* tag,int level,int flags,const char* fun,int line,const char* fmt,...)
{
    int ret,len;
    va_list varlist;

    plog_init(g_level);

    if(!g_inited){
        fprintf(stderr,"LOG module do not init,call \"plog_init\" first\n");
        return 0;
    }
    
    if(level<g_level){
        return 0;
    }

     if((len=strlen(fmt))>512){
         fprintf(stderr,"fmt is too long,may be memory out of range\n");
         return 0;
     }
        
    char prefix[256];
    int pos=0;

    prefix[0]=0;
    if(tag!=NULL){
         pos=snprintf(prefix,sizeof(prefix),"[%s] ",tag);
    }
    
    if(flags&PLOG_FLAG_TIME){
        struct timeval val;
        if(gettimeofday(&val,NULL)==0){
            pos+=snprintf(prefix+pos,sizeof(prefix)-pos,"[%d.%d]",(int)val.tv_sec,(int)val.tv_usec);
        }
    }
    if(flags&PLOG_FLAG_POS){
        pos+=snprintf(prefix+pos,sizeof(prefix)-pos,"(%s:%d) ",fun,line);
    }

    if(flags&PLOG_FLAG_ERRNO){
        pos+=snprintf(prefix+pos,sizeof(prefix)-pos,"(errno %d:%s)",pget_errno(),pstr_errno(pget_errno()));
    }
    
    char fmtnew[strlen(prefix)+strlen(fmt)+1];
    sprintf(fmtnew,"%s%s",prefix,fmt);

    va_start (varlist,fmt);
    ret=vprintf(fmtnew,varlist);
    va_end(varlist);

    if(flags&PLOG_FLAG_SYSLOG){
        va_start (varlist,fmt);
        vsyslog(mapLevel(level),fmtnew,varlist);
        va_end(varlist);
    }
    return ret;
}
