#ifndef __cloud_cmd_sender__
#define __cloud_cmd_sender__
#include<thread>
#include<vector>
#include<mutex>
#include "ros/ros.h"
#include "pixbot/block_queue.h"

using namespace pixbot;


class CloudCmdSender{
public:
  CloudCmdSender() ;

  void send(string & cmd);

  uint32_t getAsyncRespConnectionId(void);
  void setAsyncRespConnectionId(uint32_t id);

private:
  ros::NodeHandle mNodeHandle;
  ros::Timer mTimer;

  uint32_t mConnectionId;
  mutex mConnectionIdMutex;

  BlockQueue<string> mCmdQueue;
  ros::ServiceClient mServiceClient;

  void timerCallback(const ros::TimerEvent & evt);
};

#endif /* defined(__cloud_cmd_sender__) */
