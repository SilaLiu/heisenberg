#include<math.h>
#include<thread>
#include<mutex>
#include<unistd.h>
#include<fstream>
#include"ros/ros.h"
#include"std_msgs/String.h"
#include "pixbot/plt_assert.h"
#include "pixbot/data_publisher.h"
#include "pixbot/plt_config.h"
#include "pixbot/util_class.h"
#include "pixbot/system_define.h"
#include "pixbot/util_class.h"
#include "pixbot/status.h"
#include <sys/types.h>
#include "pixbot/upgrader_cmd_send.h"
#include "cloud_cmd_sender.h"
#include "pixbot/string_def.h"
#include <mutex>
#include <curl/curl.h>
#include <sys/stat.h>
#include "nlohmann/json.hpp"
#include "upgrader_node.h"
#include "pixbot/upgrader_status_get.h"
#include <time.h>

using namespace pixbot;
using namespace std;
using json = nlohmann::json;

#define UPGRADER_NODE_TAG    "UpgraderNode"

#define UPGRADER_MSG_OK ""
#define UPGRADER_MSG_FAIL "9000"
#define UPGRADER_MSG_UNKOWN_URL "9001"
#define UPGRADER_MSG_NONE_NEW "9002"
#define UPGRADER_MSG_DOWNLOAD_FAILED "9003"
#define UPGRADER_MSG_CHECK_FAILED "9004"
#define UPGRADER_MSG_QUERY_TIME_OUT "9005"



#define OTA_QUERY_TIME_OUT 30

typedef enum {
  OTA_UPGRADE_STATE_FAIL = -1,
  OTA_UPGRADE_STATE_IDLE = 0,
  OTA_UPGRADE_STATE_QUERY = 11,     
  OTA_UPGRADE_STATE_QUERING = 1,
  OTA_UPGRADE_STATE_QUERIED = 2,
  OTA_UPGRADE_STATE_DOWNLOAD = 12,  
  OTA_UPGRADE_STATE_DOWNLOADING = 3,
  OTA_UPGRADE_STATE_DOWNLOADED = 4,  
  OTA_UPGRADE_STATE_INTALL = 13,   
  OTA_UPGRADE_STATE_INTALLING = 7,
  OTA_UPGRADE_STATE_INTALLED = 8
}OtaUpgradeState;

struct FmInfo{
  bool isLoaded;  
	bool isNew;
	string name;
	string swVer;
	string time;    
	int mode;        
	string url;
	int size;        
	string update;   
  string md5;
  string fileName;
};

struct UpgraderStatus{
	OtaUpgradeState step;
  int dwnMode;
	int instMode;
	bool isNeededReboot;
	int progress;
	string ver;
  string msg;
};


class UpgraderListener;
class Upgrader;

static unique_ptr<CloudCmdSender> s_cloudCmdSender;
static shared_ptr<UpgraderListener> s_upgraderListener;
static shared_ptr<Upgrader> s_upgrader;


class UpgraderStatusPublisher{
public:
  UpgraderStatusPublisher(string name,int buff) : mNodeHandle(""), mStatusQueue(12), mPub(mNodeHandle, name, buff){
      mTimer = mNodeHandle.createTimer(ros::Duration(1), &UpgraderStatusPublisher::timerCallback, this);
  }

  void publish(UpgraderStatus & status){
    mStatusQueue.push(status);
  }

private:
  ros::NodeHandle mNodeHandle;
  BlockQueue<UpgraderStatus> mStatusQueue;
  Publisher<std_msgs::String> mPub;
  ros::Timer mTimer;

  std_msgs::String convertToJsonMsg(const UpgraderStatus &status){
    json statusJson;

    statusJson[JSON_FIELD_ID] = CMD_ID_GET_OTA_STATUS;
    statusJson[JSON_FIELD_RESP] = "getOtaStatus";

    statusJson[JSON_FIELD_BODY]["status"] = 0;
    statusJson[JSON_FIELD_BODY]["step"] = status.step;
    statusJson[JSON_FIELD_BODY]["dwnMode"] = 0; 
    statusJson[JSON_FIELD_BODY]["instMode "] = status.instMode;
    statusJson[JSON_FIELD_BODY]["reboot "] = status.isNeededReboot; 
    statusJson[JSON_FIELD_BODY]["progress"] = status.progress; 
    statusJson[JSON_FIELD_BODY]["msg"] = status.msg; 
    statusJson[JSON_FIELD_BODY]["ver"] = status.ver;

    std_msgs::String statusMsg; 
    statusMsg.data = statusJson.dump();

    PLOG_DEBUG(UPGRADER_NODE_TAG, "Publish upgrader status:%s", statusMsg.data.c_str());

    return statusMsg;
  }

  void timerCallback(const ros::TimerEvent& evt){
    UpgraderStatus status ;

    while(mStatusQueue.popNoblock(status) == 0){
      mPub.publish(convertToJsonMsg(status));
    }
  }
};


class UpgraderListener{
public:
  virtual void onStatusChanged(const Upgrader &upgrader, UpgraderStatus &newStatus, UpgraderStatus &oldStatus) = 0;
  virtual void onCmdSend(const Upgrader &upgrader, const OtaUpgradeCmd cmd) = 0;

  virtual ~UpgraderListener(){
    
  };
};


class UpgraderStatusReporter : public UpgraderListener{
  public:
  UpgraderStatusReporter(){
    mStatusPublisher = unique_ptr<UpgraderStatusPublisher>(new UpgraderStatusPublisher("UpgraderNode/upgrader_status", 24));
  }

  void onStatusChanged(const Upgrader &upgrader, UpgraderStatus &newStatus, UpgraderStatus &oldStatus) override{
    mStatusPublisher->publish(newStatus);
  }

  void onCmdSend(const Upgrader &upgrader, const OtaUpgradeCmd cmd) override{

  }

private:
   unique_ptr<UpgraderStatusPublisher> mStatusPublisher;
};
       

class UpgraderDownloader;

class UpgraderDownloaderListener{
public:
  virtual void onStarted(const UpgraderDownloader &downloader) = 0;
  virtual void onFinished(const UpgraderDownloader &downloader, const bool isSucceeded) = 0;
  virtual void onProgressChanged(const UpgraderDownloader &downloader, const int progress) = 0;

  virtual ~UpgraderDownloaderListener(){

  };
};

class UpgraderDownloader{
public:
  UpgraderDownloader(FmInfo fmInfo, shared_ptr<UpgraderDownloaderListener> listener): mFmInfo(fmInfo), mListener(listener), mCurl(NULL)
  , mIsDownloading(false), mIsSucceeded(false){
  }

  void setListener(shared_ptr<UpgraderDownloaderListener> listener){
    lock_guard<mutex> lock(mListenerMutex);

    mListener = listener;
  }

  shared_ptr<UpgraderDownloaderListener> getListener(){
    lock_guard<mutex> lock(mListenerMutex);
    return mListener;
  }

  string getPreSwVer(){
    const int SW_VER_LEN = 15;
    FILE *pFile;
    if((pFile = fopen("/userdata/ota_swver2", "r")) == NULL){
      PLOG_DEBUG(UPGRADER_NODE_TAG, "can't read ota done sw ver file");
      return "";
    }

    fseek(pFile, 0, SEEK_END);

    int len = ftell(pFile); 

    if(len < SW_VER_LEN){
      PLOG_DEBUG(UPGRADER_NODE_TAG, "invalid ota done sw ver");
      return "";
    }

    char pBuf[SW_VER_LEN + 1]; 

    rewind(pFile); 

    fread(pBuf, 1, SW_VER_LEN, pFile);
    fclose(pFile);

    pBuf[SW_VER_LEN] = 0;

    string swVer(pBuf);

    PLOG_DEBUG(UPGRADER_NODE_TAG, "get ota done sw ver:%s", swVer.c_str());

    return swVer;
  }


  bool start(bool isNeededContinue){
    string fmUrl = mFmInfo.url;
    int targetSize = mFmInfo.size;

    string preVer = getPreSwVer();

    if(preVer.size() > 5 && (preVer != mFmInfo.swVer)){
      PLOG_DEBUG(UPGRADER_NODE_TAG, "preVer:%s, ver:%s", preVer.c_str(), mFmInfo.swVer.c_str());
      system("rm /userdata/otatemp/ota.zip; sync; sleep 0.5");
    }


    FILE *fp = NULL;
  
    if (fmUrl.size() == 0){
      return false;
    }

    std::size_t pos = fmUrl.rfind('/');

    if(pos == string::npos){
      return false;
    }

    string fmFileName = mFmInfo.fileName;

    off_t offset = getFileLength(fmFileName.c_str());

    if (offset < 0){
      offset = 0;
    }

    fp = fopen(fmFileName.c_str(), "ab+");

    if (NULL == fp){ 
      PLOG_DEBUG(UPGRADER_NODE_TAG, "Open file failed at %s:%d,filename %s", __FILE__, __LINE__, fmFileName.c_str());
      return false;
    }

    CURL *curl = NULL;
    curl = curlInit();
    if (curl == NULL)    {
      fclose(fp);
      return false;
    }

    if (!isNeededContinue){
      fclose(fp);
      fp = fopen(fmFileName.c_str(), "rb+");
      if (NULL == fp){ 
        PLOG_DEBUG(UPGRADER_NODE_TAG, "Open file failed at %s:%d,filename %s", __FILE__, __LINE__, fmFileName.c_str());
        return -1;
      }
      
      curlSetDownloadOpt(curl, fmUrl.c_str(), offset, fp);
    }
    else{
      if(offset >= targetSize){
        PLOG_DEBUG(UPGRADER_NODE_TAG, "offset:%d, targetSize:%d", offset, targetSize);
        curlSetDownloadOpt(curl, fmUrl.c_str(), 0, fp);
      }
      else{
        curlSetDownloadOpt(curl, fmUrl.c_str(), offset, fp);
      }
    }
    
    mIsDownloading = true;

    shared_ptr<UpgraderDownloaderListener> listener = getListener();

    if(listener != nullptr){
      PLOG_DEBUG(UPGRADER_NODE_TAG, "start download:%s", fmUrl.c_str());
      listener->onStarted(*this);
    }

  
    string cmd = "echo " +  mFmInfo.swVer + " > /userdata/ota_swver2";

    system(cmd.c_str()); //after install, system will always reboot

    curlPerformAsync(curl, fp);

    return true;
  }
  
  void cancel(){
    lock_guard<mutex> lock(mCurlMutex);

    if(mCurl != NULL){
      curl_easy_setopt(mCurl, CURLOPT_TIMEOUT_MS, 1);
    }
  }

  bool isDownloading(){
    lock_guard<mutex> lock(mIsDownloadingMutex);
    return mIsDownloading;
  }

  bool isSucceeded(){
    lock_guard<mutex> lock(mIsSucceededMutex);
    return mIsSucceeded;
  }

  void setProgress(int progress){
    lock_guard<mutex> lock(mProgressMutex);
    mProgress = progress;
  }

  int getProgress(){
    lock_guard<mutex> lock(mProgressMutex);
    return mProgress;
  }

private:
  FmInfo mFmInfo;
  shared_ptr<UpgraderDownloaderListener> mListener;
  CURL *mCurl;
  mutex mCurlMutex;
  bool mIsDownloading;
  bool mIsSucceeded;  //download is succeeded
  mutex mIsDownloadingMutex;
  mutex mIsSucceededMutex;
  int mProgress; //download progress
  mutex mProgressMutex;
  mutex mListenerMutex;

  void setIsSucceeded(bool isSucceeded){
    lock_guard<mutex> lock(mIsSucceededMutex);
    mIsSucceeded = isSucceeded;
  }

  void setIsDownloading(bool isDownloading){
    lock_guard<mutex> lock(mIsDownloadingMutex);
    mIsDownloading = isDownloading;
  }

  CURL *curlInit(){
    mCurl = curl_easy_init();
    PLOG_DEBUG(UPGRADER_NODE_TAG, "Init curl");
    if (NULL == mCurl){
      PLOG_DEBUG(UPGRADER_NODE_TAG, "Init curl failed.");
    }
    
    return mCurl;
  }

  void curlExit(CURL *curl){
    lock_guard<mutex> lock(mCurlMutex);
	  curl_easy_cleanup(curl);

    PLOG_DEBUG(UPGRADER_NODE_TAG, "cleanup curl");

    mCurl = NULL;
  }

  CURLcode curlPerform(CURL *curl){
    PLOG_DEBUG(UPGRADER_NODE_TAG, "Perform curl");
    CURLcode ret = curl_easy_perform(curl);
    if (ret != 0){
       PLOG_DEBUG(UPGRADER_NODE_TAG, "Perform curl faild, ret=%d", ret);
    }
    PLOG_DEBUG(UPGRADER_NODE_TAG, "Perform curl done, ret=%d", ret);

    return ret;
  }

  void curlPerformAsync(CURL *curl, FILE *fp){
    setProgress(0);
    int ret = curlPerform(curl);
    if (CURLE_OK == ret){
      setIsSucceeded(true);
    }
    else{
      setIsSucceeded(false);
    }

    curlExit(curl);
    fclose(fp);

    setIsDownloading(false);

    shared_ptr<UpgraderDownloaderListener> listener = getListener();

    if(listener != nullptr){
      if(isSucceeded()){
        listener->onProgressChanged(*this, 100);
      }
      
      listener->onFinished(*this, isSucceeded());
    }
  }

  int downloadProgressCb(curl_off_t dltotal,
                           curl_off_t dlnow,
                           curl_off_t ultotal,
                           curl_off_t ulnow){
    int progress; 

    if(dltotal == 0){
      progress = 0;
    }
    else{
      progress  = (int)(100 * dlnow / dltotal);
    } 
    
    if(progress != getProgress()){
      PLOG_DEBUG(UPGRADER_NODE_TAG, "progress:[%d%%], dltotal:%ld, dlnow:%ld", progress, dltotal, dlnow);

      setProgress(progress);

      shared_ptr<UpgraderDownloaderListener> listener = getListener();

      if(listener != nullptr){
        listener->onProgressChanged(*this, progress);
      }
    }

    return 0;
  }

  void curlSetDownloadOpt(CURL *curl, const char *url, off_t offset, FILE *file){
    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, file);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 45);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 300);   
    curl_easy_setopt(curl, CURLOPT_VERBOSE, 1);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);  

    if (offset > 0){
      curl_easy_setopt(curl, CURLOPT_RESUME_FROM_LARGE, offset);
    }
    curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
    
    
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
    typedef void* (*FUNC)(void *clientp,
                                    curl_off_t dltotal,
                                    curl_off_t dlnow,
                                    curl_off_t ultotal,
                                    curl_off_t ulnow);
    FUNC callback = (FUNC)&UpgraderDownloader::downloadProgressCb;
    curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, callback);
    curl_easy_setopt(curl, CURLOPT_XFERINFODATA, this);
  
  }

  off_t getFileLength(const char *file_path) {  
    int offset = 0;  
    struct stat fileStat;  

    memset(&fileStat, 0, sizeof(struct stat));
    offset = stat(file_path, &fileStat);
    
    if (offset == 0){  
      return fileStat.st_size;  
    }  
  
    return 0;  
  }  
};

class Upgrader : public UpgraderDownloaderListener{
public:
  Upgrader(shared_ptr<UpgraderListener> listener): 
    mListener(listener), mCmdQueue(12), mDownloader(nullptr), mThread([this](){
      loop();        
      PLOG_WARN(UPGRADER_NODE_TAG, "Upgrader loop exit!");
    }){
    mFmInfo.isLoaded = false;
  }

  void onStarted(const UpgraderDownloader &downloader) override{
    PLOG_DEBUG(UPGRADER_NODE_TAG, "download onStarted");
  }

  void onFinished(const UpgraderDownloader &downloader, const bool isSucceeded) override{
    PLOG_DEBUG(UPGRADER_NODE_TAG, "download onFinished:%d", isSucceeded);
  }

  void onProgressChanged(const UpgraderDownloader &downloader, const int progress) override{
    PLOG_DEBUG(UPGRADER_NODE_TAG, "download onProgressChanged:%d%%", progress);
    FmInfo fmInfo = getFmInfo();
    sendUpgraderStatus(OTA_UPGRADE_STATE_DOWNLOADING, fmInfo.swVer, UPGRADER_MSG_OK, progress);
  }

  ~Upgrader(){
  }

  bool sendCmd(OtaUpgradeCmd cmd){
    mCmdQueue.pushNoblock(cmd);

    mListener->onCmdSend(*this, cmd);

    return true;
  }

  OtaUpgradeState getState(){
    return OTA_UPGRADE_STATE_INTALLED;
  }

  UpgraderStatus getStatus(void){
    unique_lock<mutex> lock(mStatusMutex);

    return mStatus;
  }

  void setStatus(UpgraderStatus status){
    unique_lock<mutex> lock(mStatusMutex);

    mStatus = status;
  }

  FmInfo getFmInfo(){
    lock_guard<mutex> lock(mFmInfoMutex);

    return mFmInfo;
  }

  void setFmInfo(FmInfo fmInfo){
    lock_guard<mutex> lock(mFmInfoMutex);
    mFmInfo = fmInfo;
  }

  shared_ptr<UpgraderDownloader> getDownloader(){
    lock_guard<mutex> lock(mDownloaderMutex);
    return mDownloader;
  }

private:
  UpgraderStatus mStatus;
  shared_ptr<UpgraderListener> mListener;
  BlockQueue<OtaUpgradeCmd> mCmdQueue;
  shared_ptr<UpgraderDownloader> mDownloader;
  thread mThread;
  FmInfo mFmInfo;
  mutex mStatusMutex;
  mutex mFmInfoMutex;
  mutex mDownloaderMutex;
  ros::Time timeNeededDoAutoUpgrade;
  int cnt;
  long duration;

  void setDownloader(shared_ptr<UpgraderDownloader> downloader){
    lock_guard<mutex> lock(mDownloaderMutex);
    if(mDownloader != nullptr){
      mDownloader->setListener(nullptr);
    }
    mDownloader = downloader;
  }

  bool checkIsNeededDoAutoUpgrade(){
    static char lastDoAutoUpgradeDate[32] = {0};

    tm nowtime;
    timespec time;
    clock_gettime(CLOCK_REALTIME, &time);  //获取相对于1970到现在的秒数
    localtime_r(&time.tv_sec, &nowtime);

    char nowDateStr[32] = {0};

    //sprintf(nowTimeStr, "%04d-%02d-%02d %02d:%02d:%02d", nowtime.tm_year + 1900, nowtime.tm_mon + 1, nowtime.tm_mday, nowtime.tm_hour, nowtime.tm_min, nowtime.tm_sec);
    sprintf(nowDateStr, "%04d-%02d-%02d", nowtime.tm_year + 1900, nowtime.tm_mon + 1, nowtime.tm_mday);
    
    if(strncmp(nowDateStr, lastDoAutoUpgradeDate, 10) != 0){
      //PLOG_INFO(UPGRADER_NODE_TAG, "nowDateStr:%s, lastDoAutoUpgradeDate:%s", nowDateStr, lastDoAutoUpgradeDate);
      if(nowtime.tm_hour == 2){
        PLOG_DEBUG(UPGRADER_NODE_TAG, "lastDoAutoUpgradeDate:%s", lastDoAutoUpgradeDate);
        PLOG_DEBUG(UPGRADER_NODE_TAG, "do nowDateStr:%s", nowDateStr);
        strncpy(lastDoAutoUpgradeDate, nowDateStr, 10);
        lastDoAutoUpgradeDate[10] = '\0';
        return true;
      }
    }

    if(cnt == 0){
      duration = 5 * 60;
    }
    else{
      duration = -1;
    }

    if(duration == -1){
      return false;
    }

    if((ros::Time::now() - timeNeededDoAutoUpgrade).toSec() >= duration){
      if(cnt < 1){
        cnt++;
      }

      PLOG_INFO(UPGRADER_NODE_TAG, "checkIsNeededDoAutoUpgrade:true, cnt:%d", cnt);
      
      timeNeededDoAutoUpgrade = ros::Time::now();
      return true;
    }

    return false;
  }

  void sendUpgraderStatus(OtaUpgradeState step,  string ver = "", string msg = "", float progress = 0, int instMode = 0, bool isNeededReboot = false){
    UpgraderStatus status;
    status.step = step;
    status.instMode = instMode;
    status.isNeededReboot = isNeededReboot;
    status.progress = progress;
    status.ver = ver;
    status.msg = msg;

    mListener->onStatusChanged(*this, status, mStatus);

    setStatus(status);
  }

  bool restoreToInit(){
    char cmd[512] = {0};
    
    PLOG_INFO(UPGRADER_NODE_TAG, "restoreToInit:[%s,%d]", __FUNCTION__, __LINE__);

    FmInfo fmInfo = getFmInfo();

    if (access(fmInfo.fileName.c_str(), F_OK) == 0){
      sprintf(cmd, "rm -rf %s", fmInfo.fileName.c_str());
      system(cmd);
    }
    
    sprintf(cmd, "rm -rf /userdata/ota/*");
    system(cmd);
    
    return true;
  }

  bool decompressUpgradeFile(){
    int ret = 0;
    char cmd[512] = {0};
    
    PLOG_INFO(UPGRADER_NODE_TAG, "[%s,%d]", __FUNCTION__, __LINE__);
    
    sprintf(cmd, "sudo rm -rf /userdata/ota/*;sudo unzip -q /userdata/otatemp/ota.zip -d /userdata/ota/");
    ret = system(cmd);

    if(ret != 0){
      PLOG_INFO(UPGRADER_NODE_TAG, "decompressUpgradeFile fail, ret=%d", ret);
    }

    return ret == 0 ? true : false;
  }

  bool checkDecompressedSw(){
    FILE* fpRead = NULL;
    char re[512] = {0};
    
    fpRead = popen("/bin/ota_check_decompressed.sh","r");
    fread(re,sizeof(char),sizeof(re)-1,fpRead);
    PLOG_INFO(UPGRADER_NODE_TAG, "checkDecompressedSw result: %s", re);
    pclose(fpRead);

    if(strstr(re, "check_ok") != NULL){
      return true;
    }
    else{
      return false;
    }
  }

  bool checkDownloadedSwIsOk(bool isNeededRestoreToInit){
    bool isOk = false;
    FILE* fpRead = NULL;
    char re_str[64] = {0};
    char cmd[512] = {0};

    FmInfo fmInfo = getFmInfo();

    if(access(fmInfo.fileName.c_str(), F_OK) == 0){
      sprintf(cmd, "md5sum %s | awk '{print $1}'", fmInfo.fileName.c_str());
      fpRead = popen(cmd, "r");
      memset(re_str, '\0', sizeof(re_str));
      fread(re_str, sizeof(char), sizeof(re_str)-1, fpRead);

      PLOG_INFO(UPGRADER_NODE_TAG, "result is: %s, file_md5:%s", re_str, fmInfo.md5.c_str());
      pclose(fpRead);

      if((strlen(fmInfo.md5.c_str()) == 32) 
        && (strncmp(re_str, fmInfo.md5.c_str(), 32) == 0)){
        return true;
      }
      else{
        if(isNeededRestoreToInit){
          restoreToInit(); 
        }
        
        return false;
      }
    }
    else{
      if(isNeededRestoreToInit){
        restoreToInit(); 
      }
      return false;
    }
  }


  bool checkAndDecompressDownloadedSw(){
    bool isOk = false;
    FILE* fpRead = NULL;
    char re_str[64] = {0};
    char cmd[512] = {0};

    FmInfo fmInfo = getFmInfo();

    if(access(fmInfo.fileName.c_str(), F_OK) == 0){
      if(checkDownloadedSwIsOk(true)){
        isOk = decompressUpgradeFile();
        if (!isOk){ //decompress failed
          restoreToInit(); 
          return isOk;
        }
        else{
          isOk = checkDecompressedSw();
          if (!isOk){  
            restoreToInit(); 
            return isOk;
          }
        }
      }
      else {
        restoreToInit();	
        isOk = false;		
      }
    }
    else{
      restoreToInit(); 	
      isOk = false;	
    }
    
    return isOk;
  }


  void doInstall(){
    FmInfo fmInfo = getFmInfo();
    string cmd = "nohup /bin/ota_install.sh " + getFmInfo().swVer + " &";

    system(cmd.c_str()); //after install, system will always reboot
  }

  string getOtaDoneSwVer(){
    const int SW_VER_LEN = 15;
    FILE *pFile;
    if((pFile = fopen("/userdata/ota_swver", "r")) == NULL){
      PLOG_DEBUG(UPGRADER_NODE_TAG, "can't read ota done sw ver file");
      return "";
    }

    fseek(pFile, 0, SEEK_END);

    int len = ftell(pFile); 

    if(len < SW_VER_LEN){
      PLOG_DEBUG(UPGRADER_NODE_TAG, "invalid ota done sw ver");
      return "";
    }

    char pBuf[SW_VER_LEN + 1]; 

    rewind(pFile); 

    fread(pBuf, 1, SW_VER_LEN, pFile);
    fclose(pFile);

    pBuf[SW_VER_LEN] = 0;

    string swVer(pBuf);

    PLOG_DEBUG(UPGRADER_NODE_TAG, "get ota done sw ver:%s", swVer.c_str());

    return swVer;
  }

  void loop(void){
    static OtaUpgradeState state = OTA_UPGRADE_STATE_IDLE;

    OtaUpgradeCmd cmd;

    ros::Time queryStartTime = ros::Time::now();
    timeNeededDoAutoUpgrade = ros::Time::now();
    cnt = 0;
    duration = 0;

    bool isFoundOtaDoneFlag = false;

    bool isAutoStarted = true; //true: ota query is auto started by application or server send upgrade cmd in white list; false: started by user

    if (access("/userdata/ota_done", F_OK) == 0){
      PLOG_INFO(UPGRADER_NODE_TAG, "found ota_done flat and report installed");
      system("rm /userdata/ota_done; sync");
      system("rm -rf /userdata/otatemp/*; sync");
      system("rm -rf /userdata/ota/*; sync");

      state = OTA_UPGRADE_STATE_INTALLED;

      string swVer = getOtaDoneSwVer();

      sendUpgraderStatus(OTA_UPGRADE_STATE_INTALLED, swVer);
    }

    while(true){
      if(mCmdQueue.popNoblock(cmd) == 0){  //pop one cmd ok
        //just do nothing
      }
      else{
        cmd = OTA_UPGRADE_CMD_NONE;
      }

      switch (state){
      case OTA_UPGRADE_STATE_IDLE:{
        isAutoStarted = false;
        if(cmd == OTA_UPGRADE_CMD_START){
          isAutoStarted = false;
          state = OTA_UPGRADE_STATE_QUERY;
        }
        else if(cmd == OTA_UPGRADE_CMD_START_IN_WL){
          isAutoStarted = true;
          state = OTA_UPGRADE_STATE_QUERY;
        }
        else if(cmd == OTA_UPGRADE_CMD_DOWNLOAD){
          isAutoStarted = false;
          state = OTA_UPGRADE_STATE_DOWNLOAD;
        }
        else if(cmd == OTA_UPGRADE_CMD_INSTALL){
          isAutoStarted = false;
          state = OTA_UPGRADE_STATE_INTALL;
        }
        else if(cmd == OTA_UPGRADE_CMD_NONE){
          if(checkIsNeededDoAutoUpgrade()){
            UpgraderStatus status = s_upgrader->getStatus();
            PLOG_INFO(UPGRADER_NODE_TAG, "checkIsNeededDoAutoUpgrade: true");
            isAutoStarted = true;
            if(//status.step == OTA_UPGRADE_STATE_DOWNLOAD
              //|| status.step == OTA_UPGRADE_STATE_DOWNLOADING
              status.step == OTA_UPGRADE_STATE_DOWNLOADED
              //|| status.step == OTA_UPGRADE_STATE_INTALL
              //|| status.step == OTA_UPGRADE_STATE_INTALLING
              ){
              FmInfo fmInfo = getFmInfo();
              //sendUpgraderStatus(OTA_UPGRADE_STATE_DOWNLOADED, fmInfo.swVer);
              PLOG_DEBUG(UPGRADER_NODE_TAG, "checkIsNeededDoAutoUpgrade, already download");
              state = OTA_UPGRADE_STATE_DOWNLOADED;
            }
            else{
              PLOG_DEBUG(UPGRADER_NODE_TAG, "checkIsNeededDoAutoUpgrade, not download");
              state = OTA_UPGRADE_STATE_QUERY;
            }
          }
        }
        else{
           PLOG_WARN(UPGRADER_NODE_TAG, "unkown OTA_UPGRADE_CMD:%d", cmd);
        }
        break;
      }
      case OTA_UPGRADE_STATE_QUERY:{
        if(cmd == OTA_UPGRADE_CMD_START){
          isAutoStarted = false;
        }
        else if(cmd == OTA_UPGRADE_CMD_START_IN_WL){
          isAutoStarted = true;
        }
        else if(cmd == OTA_UPGRADE_CMD_DOWNLOAD){
          isAutoStarted = false;
          state = OTA_UPGRADE_STATE_DOWNLOAD;
          PLOG_WARN(UPGRADER_NODE_TAG, "state in OTA_UPGRADE_STATE_QUERY, but got OTA_UPGRADE_CMD_DOWNLOAD");
          break;
        }
        else if(cmd == OTA_UPGRADE_CMD_INSTALL){
          isAutoStarted = false;
          state = OTA_UPGRADE_STATE_INTALL;
          PLOG_WARN(UPGRADER_NODE_TAG, "state in OTA_UPGRADE_STATE_QUERY, but got OTA_UPGRADE_CMD_INSTALL");
          break;
        }
        else if(cmd == OTA_UPGRADE_CMD_NONE){
        }
        else{
          PLOG_WARN(UPGRADER_NODE_TAG, "unkown OTA_UPGRADE_CMD:%d", cmd);
        }

        state = OTA_UPGRADE_STATE_QUERING;
        PLOG_DEBUG(UPGRADER_NODE_TAG, "start OTA_UPGRADE_STATE_QUERING");
        sendUpgraderStatus(OTA_UPGRADE_STATE_QUERING);

        FmInfo fmInfo = getFmInfo();
        fmInfo.isLoaded = false;
        setFmInfo(fmInfo);

        queryStartTime = ros::Time::now();
        string cmdStr(CMD_ID_QUERY_OTA_VER);
        s_cloudCmdSender->send(cmdStr);

        break;
      }
      case OTA_UPGRADE_STATE_QUERING:{
        if(cmd == OTA_UPGRADE_CMD_START){
          isAutoStarted = false;
        }
        else if(cmd == OTA_UPGRADE_CMD_START_IN_WL){
          isAutoStarted = true;
        }
        else if(cmd == OTA_UPGRADE_CMD_DOWNLOAD){
          isAutoStarted = false;
          state = OTA_UPGRADE_STATE_DOWNLOAD;
          PLOG_WARN(UPGRADER_NODE_TAG, "state in OTA_UPGRADE_STATE_QUERING, but got OTA_UPGRADE_CMD_DOWNLOAD");
          break;
        }
        else if(cmd == OTA_UPGRADE_CMD_INSTALL){
          isAutoStarted = false;
          state = OTA_UPGRADE_STATE_INTALL;
          PLOG_WARN(UPGRADER_NODE_TAG, "state in OTA_UPGRADE_STATE_QUERING, but got OTA_UPGRADE_CMD_INSTALL");
          break;
        }
        else if(cmd == OTA_UPGRADE_CMD_NONE){
        }
        else{
           PLOG_WARN(UPGRADER_NODE_TAG, "unkown OTA_UPGRADE_CMD:%d", cmd);
        }

        FmInfo fmInfo = getFmInfo();

        if(fmInfo.isLoaded){
          state = OTA_UPGRADE_STATE_QUERIED;
          sendUpgraderStatus(OTA_UPGRADE_STATE_QUERIED, fmInfo.swVer);
        }
        else{
          if((ros::Time::now() - queryStartTime).toSec() > OTA_QUERY_TIME_OUT){
            PLOG_DEBUG(UPGRADER_NODE_TAG, "OTA_UPGRADE_STATE_QUERY timeout");
            state = OTA_UPGRADE_STATE_IDLE;
            sendUpgraderStatus(OTA_UPGRADE_STATE_FAIL, "", UPGRADER_MSG_QUERY_TIME_OUT); //query failed
          }
        }
        break;
      }
      case OTA_UPGRADE_STATE_QUERIED:{
        if(cmd == OTA_UPGRADE_CMD_START){
          isAutoStarted = false;
        }
        else if(cmd == OTA_UPGRADE_CMD_START_IN_WL){
          isAutoStarted = true;
        }
        else if(cmd == OTA_UPGRADE_CMD_DOWNLOAD){
          isAutoStarted = false;
          state = OTA_UPGRADE_STATE_DOWNLOAD;
          PLOG_WARN(UPGRADER_NODE_TAG, "state in OTA_UPGRADE_STATE_QUERIED, but got OTA_UPGRADE_STATE_DOWNLOAD");
        }
        else if(cmd == OTA_UPGRADE_CMD_INSTALL){
          isAutoStarted = false;
          state = OTA_UPGRADE_STATE_INTALL;
          PLOG_WARN(UPGRADER_NODE_TAG, "state in OTA_UPGRADE_STATE_QUERIED, but got OTA_UPGRADE_CMD_INSTALL");
          break;
        }
        else if(cmd == OTA_UPGRADE_CMD_NONE){
        }
        else{
          PLOG_WARN(UPGRADER_NODE_TAG, "unkown OTA_UPGRADE_CMD:%d", cmd);
        }

        FmInfo fmInfo = getFmInfo();

        if(fmInfo.isNew){
          PLOG_DEBUG(UPGRADER_NODE_TAG, "there is a new firmware:%s", fmInfo.swVer.c_str());

          if(isAutoStarted){
            PLOG_DEBUG(UPGRADER_NODE_TAG, "isAutoStarted true force download fm");
            state = OTA_UPGRADE_STATE_DOWNLOAD; //auto start download
            sendUpgraderStatus(OTA_UPGRADE_STATE_DOWNLOAD, fmInfo.swVer); 
          }
          else{
            state = OTA_UPGRADE_STATE_IDLE;
          }
        }
        else{
          PLOG_DEBUG(UPGRADER_NODE_TAG, "not any new firmware");
          state = OTA_UPGRADE_STATE_IDLE;
          sendUpgraderStatus(OTA_UPGRADE_STATE_QUERIED, fmInfo.swVer, UPGRADER_MSG_NONE_NEW); 
          sendUpgraderStatus(OTA_UPGRADE_STATE_IDLE);
        }

        break;
      }
      case OTA_UPGRADE_STATE_DOWNLOAD:{
        if(cmd == OTA_UPGRADE_CMD_START){
          isAutoStarted = false;
        }
        else if(cmd == OTA_UPGRADE_CMD_START_IN_WL){
          isAutoStarted = true;
        }
        else if(cmd == OTA_UPGRADE_CMD_DOWNLOAD){
          isAutoStarted = false;
        }
        else if(cmd == OTA_UPGRADE_CMD_INSTALL){
          isAutoStarted = false;
          state = OTA_UPGRADE_STATE_INTALL;
          PLOG_WARN(UPGRADER_NODE_TAG, "state in OTA_UPGRADE_STATE_DOWNLOAD, but got OTA_UPGRADE_CMD_INSTALL");
          break;
        }
        else if(cmd == OTA_UPGRADE_CMD_NONE){
        }
        else{
           PLOG_WARN(UPGRADER_NODE_TAG, "unkown OTA_UPGRADE_CMD:%d", cmd);
        }

        FmInfo fmInfo = getFmInfo();

        if(fmInfo.isLoaded == false){
          sendUpgraderStatus(OTA_UPGRADE_STATE_FAIL, fmInfo.swVer, UPGRADER_MSG_UNKOWN_URL);
          state = OTA_UPGRADE_STATE_IDLE;
        }
        else{
          if(checkDownloadedSwIsOk(false)){
            FmInfo fmInfo = getFmInfo();
            sendUpgraderStatus(OTA_UPGRADE_STATE_DOWNLOADING, fmInfo.swVer, "", 100);
                
            sendUpgraderStatus(OTA_UPGRADE_STATE_DOWNLOADED, fmInfo.swVer);
            PLOG_DEBUG(UPGRADER_NODE_TAG, "already download");
            state = OTA_UPGRADE_STATE_DOWNLOADED;
          }
          else{
            shared_ptr<UpgraderDownloader> downloader = getDownloader();

            if((downloader == nullptr || ((downloader != nullptr) && !(downloader->isDownloading())))){
              state = OTA_UPGRADE_STATE_DOWNLOADING;
              sendUpgraderStatus(OTA_UPGRADE_STATE_DOWNLOADING, fmInfo.swVer);
              setDownloader(shared_ptr<UpgraderDownloader>(new UpgraderDownloader(fmInfo, s_upgrader)));
              getDownloader()->start(true);
            }
            else{
              //wait old downloading stop
            }
          }
        }
        break;
      }
      case OTA_UPGRADE_STATE_DOWNLOADING:{
        if(cmd == OTA_UPGRADE_CMD_START){
          isAutoStarted = false;
        }
        else if(cmd == OTA_UPGRADE_CMD_START_IN_WL){
          isAutoStarted = true;
        }
        else if(cmd == OTA_UPGRADE_CMD_DOWNLOAD){
          isAutoStarted = false;
        }
        else if(cmd == OTA_UPGRADE_CMD_INSTALL){
          isAutoStarted = false;
          PLOG_WARN(UPGRADER_NODE_TAG, "state in OTA_UPGRADE_STATE_DOWNLOADING, but got OTA_UPGRADE_CMD_INSTALL");
        }
        else if(cmd == OTA_UPGRADE_CMD_NONE){
        }
        else{
          PLOG_WARN(UPGRADER_NODE_TAG, "unkown OTA_UPGRADE_CMD:%d", cmd);
        }

        shared_ptr<UpgraderDownloader> downloader = getDownloader();

        if(!(downloader->isDownloading())){
          FmInfo fmInfo = getFmInfo();

          if(downloader->isSucceeded()){
            sendUpgraderStatus(OTA_UPGRADE_STATE_DOWNLOADED, fmInfo.swVer);
            PLOG_DEBUG(UPGRADER_NODE_TAG, "download succeeded");
            state = OTA_UPGRADE_STATE_DOWNLOADED;
          }
          else{
            sendUpgraderStatus(OTA_UPGRADE_STATE_FAIL, fmInfo.swVer, UPGRADER_MSG_DOWNLOAD_FAILED);
            PLOG_DEBUG(UPGRADER_NODE_TAG, "download faild");
            if(cnt == 0){
              if((ros::Time::now() - timeNeededDoAutoUpgrade).toSec() >= 285){
                PLOG_DEBUG(UPGRADER_NODE_TAG, "download faild handle");
                timeNeededDoAutoUpgrade = ros::Time::now();
                cnt = 1;
                duration = -1;
              }
            }

 
            state = OTA_UPGRADE_STATE_IDLE;
          }
        }
        break;
      }
      case OTA_UPGRADE_STATE_DOWNLOADED:{
        if(cmd == OTA_UPGRADE_CMD_START){
          isAutoStarted = false;
        }
        else if(cmd == OTA_UPGRADE_CMD_START_IN_WL){
          isAutoStarted = true;
        }
        else if(cmd == OTA_UPGRADE_CMD_DOWNLOAD){
          isAutoStarted = false;
        }
        else if(cmd == OTA_UPGRADE_CMD_INSTALL){
          isAutoStarted = false;
          PLOG_WARN(UPGRADER_NODE_TAG, "state in OTA_UPGRADE_STATE_DOWNLOADED, but got OTA_UPGRADE_CMD_INSTALL");
        }
        else if(cmd == OTA_UPGRADE_CMD_NONE){
        }
        else{
          PLOG_WARN(UPGRADER_NODE_TAG, "unkown OTA_UPGRADE_CMD:%d", cmd);
        }
  
        FmInfo fmInfo = getFmInfo();
        if(isAutoStarted && fmInfo.mode){
          PLOG_DEBUG(UPGRADER_NODE_TAG, "force install fm");
          state = OTA_UPGRADE_STATE_INTALL;
          sendUpgraderStatus(OTA_UPGRADE_STATE_INTALLING, fmInfo.swVer);
        }
        else{
          PLOG_DEBUG(UPGRADER_NODE_TAG, "need start install by user");
          state = OTA_UPGRADE_STATE_IDLE;
          //sendUpgraderStatus(OTA_UPGRADE_STATE_IDLE);
        }

        break;
      }
      case OTA_UPGRADE_STATE_INTALL:{
        FmInfo fmInfo = getFmInfo();
        state = OTA_UPGRADE_STATE_INTALLING;
        sendUpgraderStatus(OTA_UPGRADE_STATE_INTALLING, fmInfo.swVer);

        if(checkAndDecompressDownloadedSw()){
          PLOG_DEBUG(UPGRADER_NODE_TAG, "checkDownloadedSwIsOk:ok");
          doInstall(); 
        }
        else{
          PLOG_WARN(UPGRADER_NODE_TAG, "checkDownloadedSwIsOk:not ok");
          sendUpgraderStatus(OTA_UPGRADE_STATE_FAIL, fmInfo.swVer, UPGRADER_MSG_CHECK_FAILED);
          state = OTA_UPGRADE_STATE_IDLE;
        }
        break;
      }
      case OTA_UPGRADE_STATE_INTALLING:{

        break;
      }
      case OTA_UPGRADE_STATE_INTALLED:{
        state = OTA_UPGRADE_STATE_IDLE;
        break;
      }
      default:
        break;
      }
      
      usleep(50000); 
    } 
  }
};

/**
 * send_cmd service handler, send cmd to Upgrader
 */
static bool sendCmdToUpgrader(pixbot::upgrader_cmd_sendRequest &req, pixbot::upgrader_cmd_sendResponse &resp){
  int cmdId = req.cmdId;

  PLOG_DEBUG(UPGRADER_NODE_TAG, "call send_upgrader_cmd srv, cmdId:%d", cmdId);

  if(s_upgrader->sendCmd((OtaUpgradeCmd)cmdId)){
    resp.status = status::PROCESS_OK;
    return true;
  }
  else{
    resp.status = status::PROCESS_ERROR;
    return false;
  }
}

static bool getUpgraderStatus(pixbot::upgrader_status_getRequest &req, pixbot::upgrader_status_getResponse &resp){
  UpgraderStatus status = s_upgrader->getStatus();

  resp.step = status.step;
  resp.dwnMode = status.dwnMode;
  resp.isNeededReboot = status.isNeededReboot;
  resp.progress = status.progress;
  resp.ver = status.ver;
  resp.msg = status.msg;

  PLOG_DEBUG(UPGRADER_NODE_TAG, "getUpgraderStatus, step:%d", resp.step);

  return true;
}

static void cloudCmdRespCb(const std_msgs::String & respMsg){
  PLOG_DEBUG(UPGRADER_NODE_TAG, "upgrader node got sub cloudCmdRespCb:%s", respMsg.data.c_str());

  string data = respMsg.data;
  json cmdJson;

  try{
    cmdJson = json::parse(data);

    if(cmdJson.is_object()){
      try{
        const string& cmdId = cmdJson[JSON_FIELD_ID].get_ref<const string&>();

        if(cmdId == CMD_ID_QUERY_OTA_VER){
          FmInfo fmInfo;
          int hasNew = cmdJson[JSON_FIELD_BODY]["hasNew"];
          fmInfo.isLoaded = hasNew? true : false;
          fmInfo.isNew = hasNew? true : false;
          fmInfo.swVer = cmdJson[JSON_FIELD_BODY]["swVer"];
          fmInfo.url = cmdJson[JSON_FIELD_BODY]["url"];
          fmInfo.size = cmdJson[JSON_FIELD_BODY]["size"];
          fmInfo.update = cmdJson[JSON_FIELD_BODY]["update"];
          fmInfo.time = cmdJson[JSON_FIELD_BODY]["time"];
          fmInfo.mode = cmdJson[JSON_FIELD_BODY]["mode"];

          std::size_t startPos = fmInfo.url.rfind('_');
          std::size_t endPos = fmInfo.url.rfind('.');

          if((startPos != string::npos) && (endPos != string::npos) && (endPos - startPos == 33)){
            string md5Str(fmInfo.url, startPos + 1, 32);
            fmInfo.md5 = md5Str;
            PLOG_DEBUG(UPGRADER_NODE_TAG, "got ota sw md5:%s, isNew:%d", fmInfo.md5.c_str(), fmInfo.isNew);
          }

          fmInfo.fileName = "/userdata/otatemp/ota.zip";

          fmInfo.isLoaded = true;

          s_upgrader->setFmInfo(fmInfo);
        }
      }catch(invalid_argument e){
      }
    }
  }catch(invalid_argument e){
  }
}

static shared_ptr<ros::NodeHandle> s_GlobalHandle;

int main(int argc, char **argv){
  curl_global_init(CURL_GLOBAL_DEFAULT);

  ros::init(argc, argv, "UpgraderNode");
  ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME, UPGRADER_NODE_DEBUG_LEVEL);
  auto g = make_shared<ros::NodeHandle>("~");

  s_upgraderListener = make_shared<UpgraderStatusReporter>();
  s_upgrader = shared_ptr<Upgrader>(new Upgrader(s_upgraderListener));

  ros::ServiceServer cloudCmdSendSrv = g->advertiseService("upgrader_cmd_send", sendCmdToUpgrader);
  ros::ServiceServer pgraderStatusGetSrv = g->advertiseService("upgrader_status_get", getUpgraderStatus);

  s_cloudCmdSender = unique_ptr<CloudCmdSender>(new CloudCmdSender());

  s_GlobalHandle=make_shared<ros::NodeHandle>("");
  ros::Subscriber cloudCmdRespSub = s_GlobalHandle->subscribe("CloudNode/cloud_cmd_resp", 12, cloudCmdRespCb);

  ros::spin();

  curl_global_cleanup();
  
  return 0;
}