#include "cloud_cmd_sender.h"
#include "pixbot/cloud_cmd_send.h"
#include "pixbot/string_def.h"

using namespace pixbot;

CloudCmdSender::CloudCmdSender() 
    : mNodeHandle(""), mConnectionId(0), mCmdQueue(12){
      mTimer = mNodeHandle.createTimer(ros::Duration(0.5), &CloudCmdSender::timerCallback, this);
      mServiceClient = mNodeHandle.serviceClient<cloud_cmd_send>("CloudNode/cloud_cmd_send");
  }

void CloudCmdSender::send(string & cmd){
  mCmdQueue.pushNoblock(cmd);
}

uint32_t CloudCmdSender::getAsyncRespConnectionId(void){
  unique_lock<mutex> lock(mConnectionIdMutex);

  return mConnectionId;
}

void CloudCmdSender::setAsyncRespConnectionId(uint32_t id){
  unique_lock<mutex> lock(mConnectionIdMutex);

  mConnectionId = id;
}


void CloudCmdSender::timerCallback(const ros::TimerEvent & evt){
  string cmd ;

  while(mCmdQueue.popNoblock(cmd) == 0){
    if(cmd == CMD_ID_QUERY_OTA_VER){
      cloud_cmd_send cloudCmd;
      cloudCmd.request.cmdName = "otaQuery";
      cloudCmd.request.seq = 0;

      mServiceClient.call(cloudCmd);
    }
  }
}