#ifndef __upgrader_node__
#define __upgrader_node__

typedef enum{
  OTA_UPGRADE_CMD_START,       
  OTA_UPGRADE_CMD_START_IN_WL,  
  OTA_UPGRADE_CMD_DOWNLOAD,     
  OTA_UPGRADE_CMD_INSTALL,      
  OTA_UPGRADE_CMD_CANCEL,       
  OTA_UPGRADE_CMD_NONE          
}OtaUpgradeCmd;

#endif /* defined(__upgrader_node__) */
