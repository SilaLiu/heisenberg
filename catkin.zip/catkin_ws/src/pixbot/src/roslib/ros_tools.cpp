#include<stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "pixbot/ros_tools.h"
#include"std_msgs/String.h"
#include "pixbot/status.h"
#include "pixbot/system_define.h"
#include "pixbot/plt_tools.h"

namespace pixbot{
static void   string_callback(const std_msgs::String::ConstPtr& msg)
{
    //do nothing
    ROS_DEBUG("%s\n",msg->data.c_str());
}
}