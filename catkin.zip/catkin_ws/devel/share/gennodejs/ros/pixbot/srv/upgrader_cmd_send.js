// Auto-generated. Do not edit!

// (in-package pixbot.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class upgrader_cmd_sendRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.cmdId = null;
    }
    else {
      if (initObj.hasOwnProperty('cmdId')) {
        this.cmdId = initObj.cmdId
      }
      else {
        this.cmdId = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type upgrader_cmd_sendRequest
    // Serialize message field [cmdId]
    bufferOffset = _serializer.int32(obj.cmdId, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type upgrader_cmd_sendRequest
    let len;
    let data = new upgrader_cmd_sendRequest(null);
    // Deserialize message field [cmdId]
    data.cmdId = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pixbot/upgrader_cmd_sendRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c69702d14ca969350dc2da8525f4211c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #command id, type is OtaUpgradeCmd
    int32 cmdId
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new upgrader_cmd_sendRequest(null);
    if (msg.cmdId !== undefined) {
      resolved.cmdId = msg.cmdId;
    }
    else {
      resolved.cmdId = 0
    }

    return resolved;
    }
};

class upgrader_cmd_sendResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.status = null;
    }
    else {
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type upgrader_cmd_sendResponse
    // Serialize message field [status]
    bufferOffset = _serializer.int8(obj.status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type upgrader_cmd_sendResponse
    let len;
    let data = new upgrader_cmd_sendResponse(null);
    // Deserialize message field [status]
    data.status = _deserializer.int8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pixbot/upgrader_cmd_sendResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '581cc55c12abfc219e446416014f6d0e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int8 status
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new upgrader_cmd_sendResponse(null);
    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    return resolved;
    }
};

module.exports = {
  Request: upgrader_cmd_sendRequest,
  Response: upgrader_cmd_sendResponse,
  md5sum() { return '43aac1ce2548a3039f2cfe4387f23991'; },
  datatype() { return 'pixbot/upgrader_cmd_send'; }
};
