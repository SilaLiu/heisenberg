// Auto-generated. Do not edit!

// (in-package pixbot.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class upgrader_status_getRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type upgrader_status_getRequest
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type upgrader_status_getRequest
    let len;
    let data = new upgrader_status_getRequest(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pixbot/upgrader_status_getRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new upgrader_status_getRequest(null);
    return resolved;
    }
};

class upgrader_status_getResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.step = null;
      this.dwnMode = null;
      this.instMode = null;
      this.isNeededReboot = null;
      this.progress = null;
      this.ver = null;
      this.msg = null;
    }
    else {
      if (initObj.hasOwnProperty('step')) {
        this.step = initObj.step
      }
      else {
        this.step = 0;
      }
      if (initObj.hasOwnProperty('dwnMode')) {
        this.dwnMode = initObj.dwnMode
      }
      else {
        this.dwnMode = 0;
      }
      if (initObj.hasOwnProperty('instMode')) {
        this.instMode = initObj.instMode
      }
      else {
        this.instMode = 0;
      }
      if (initObj.hasOwnProperty('isNeededReboot')) {
        this.isNeededReboot = initObj.isNeededReboot
      }
      else {
        this.isNeededReboot = false;
      }
      if (initObj.hasOwnProperty('progress')) {
        this.progress = initObj.progress
      }
      else {
        this.progress = 0;
      }
      if (initObj.hasOwnProperty('ver')) {
        this.ver = initObj.ver
      }
      else {
        this.ver = '';
      }
      if (initObj.hasOwnProperty('msg')) {
        this.msg = initObj.msg
      }
      else {
        this.msg = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type upgrader_status_getResponse
    // Serialize message field [step]
    bufferOffset = _serializer.int32(obj.step, buffer, bufferOffset);
    // Serialize message field [dwnMode]
    bufferOffset = _serializer.int32(obj.dwnMode, buffer, bufferOffset);
    // Serialize message field [instMode]
    bufferOffset = _serializer.int32(obj.instMode, buffer, bufferOffset);
    // Serialize message field [isNeededReboot]
    bufferOffset = _serializer.bool(obj.isNeededReboot, buffer, bufferOffset);
    // Serialize message field [progress]
    bufferOffset = _serializer.int32(obj.progress, buffer, bufferOffset);
    // Serialize message field [ver]
    bufferOffset = _serializer.string(obj.ver, buffer, bufferOffset);
    // Serialize message field [msg]
    bufferOffset = _serializer.string(obj.msg, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type upgrader_status_getResponse
    let len;
    let data = new upgrader_status_getResponse(null);
    // Deserialize message field [step]
    data.step = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [dwnMode]
    data.dwnMode = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [instMode]
    data.instMode = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [isNeededReboot]
    data.isNeededReboot = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [progress]
    data.progress = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [ver]
    data.ver = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [msg]
    data.msg = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.ver.length;
    length += object.msg.length;
    return length + 25;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pixbot/upgrader_status_getResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '17461d651a9960f591dca06bffdf5016';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 step
    int32 dwnMode
    int32 instMode
    bool isNeededReboot
    int32 progress
    string ver
    string msg
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new upgrader_status_getResponse(null);
    if (msg.step !== undefined) {
      resolved.step = msg.step;
    }
    else {
      resolved.step = 0
    }

    if (msg.dwnMode !== undefined) {
      resolved.dwnMode = msg.dwnMode;
    }
    else {
      resolved.dwnMode = 0
    }

    if (msg.instMode !== undefined) {
      resolved.instMode = msg.instMode;
    }
    else {
      resolved.instMode = 0
    }

    if (msg.isNeededReboot !== undefined) {
      resolved.isNeededReboot = msg.isNeededReboot;
    }
    else {
      resolved.isNeededReboot = false
    }

    if (msg.progress !== undefined) {
      resolved.progress = msg.progress;
    }
    else {
      resolved.progress = 0
    }

    if (msg.ver !== undefined) {
      resolved.ver = msg.ver;
    }
    else {
      resolved.ver = ''
    }

    if (msg.msg !== undefined) {
      resolved.msg = msg.msg;
    }
    else {
      resolved.msg = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: upgrader_status_getRequest,
  Response: upgrader_status_getResponse,
  md5sum() { return '17461d651a9960f591dca06bffdf5016'; },
  datatype() { return 'pixbot/upgrader_status_get'; }
};
