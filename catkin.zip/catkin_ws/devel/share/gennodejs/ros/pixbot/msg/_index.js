
"use strict";

let status = require('./status.js');

module.exports = {
  status: status,
};
